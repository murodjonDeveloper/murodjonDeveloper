from aiogram import types


async def set_default_commands(dp):
    await dp.bot.set_my_commands(
        [
            types.BotCommand("start", "lichkada ishlaydi"),
            types.BotCommand("help", "lichkada ishlaydi"),
            types.BotCommand("mute", "mute qilish"),
            types.BotCommand("unmute", "mutedan chiqarish"),
            types.BotCommand("ban", "guruhdan haydash"),
            types.BotCommand("unban", "guruhga qushilishga ruxsat"),
        ]
    )
