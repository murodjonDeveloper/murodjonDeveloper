from aiogram import types
from utils.set_bot_commands import set_default_commands
from loader import dp
from filters import IsGroup
import asyncio


@dp.message_handler(IsGroup(), commands="help")
async def send_for_menu(message: types.Message):
    await set_default_commands(dp)
    mt_mess = await message.answer("bu komandani botni lichkasida ishlating")
    await asyncio.sleep(3)
    await mt_mess.delete()
    await message.delete()


@dp.message_handler(IsGroup(), commands="start")
async def send_for_menu(message: types.Message):
    mt_mess = await message.answer("bu komandani botni lichkasida ishlating")
    await asyncio.sleep(3)
    await mt_mess.delete()
    await message.delete()