import asyncio
import datetime
import re

import aiogram
from aiogram import types
from aiogram.dispatcher.filters import Command
from aiogram.utils.exceptions import BadRequest

from filters.admins import AdminFilter
from filters.group_filters import IsGroup
from loader import dp


@dp.message_handler(IsGroup(), Command("mute", prefixes="!/"), AdminFilter())
async def read_only_mode(message: types.Message):
    global member_id
    try:
        member_id = message.reply_to_message.from_user.id
    except:
        my_mess = await message.answer("hatolik aniqlandi qaytadan urunib ko'ring")
        await asyncio.sleep(3)
        await dp.bot.delete_message(message_id=my_mess.message_id, chat_id=my_mess.chat.id)
        return
    command_parse = re.compile(r"(!mute|/mute) ?(\d+)? ?([\w+\D]+)?")
    parsed = command_parse.match(message.text)
    time = parsed.group(2)
    comment = parsed.group(3)
    if not time:
        time = 5
    time = int(time)
    until_date = datetime.datetime.now() + datetime.timedelta(minutes=time)
    try:
        await message.chat.restrict(user_id=member_id, can_send_messages=False, until_date=until_date)
        await message.reply_to_message.delete()
    except aiogram.utils.exceptions.BadRequest as err:
        await message.answer(f"Xato! {err.args}")
        return
    await message.answer(f"Foydalanuvchi {message.reply_to_message.from_user.full_name} {time} "
                         f"minut yozishdan mahrum qilindi.\n"
                         f"Sabab: \n<b>{comment}</b>")
    service_message = await message.reply("habar 3 sekunddan so'ng o'chadi.")
    await asyncio.sleep(3)
    await message.delete()
    await service_message.delete()


@dp.message_handler(IsGroup(), Command("unmute", prefixes="!/"), AdminFilter())
async def undo_read_only_mode(message: types.Message):
    try:
        member = message.reply_to_message.from_user
    except:
        member = await message.answer("hatolik aniqlandi qaytadan urunib ko'ring")
        await asyncio.sleep(3)
        await dp.bot.delete_message(message_id=member.message_id, chat_id=member.chat.id)
        return
    member_id1 = member.id

    user_allowed = types.ChatPermissions(
        can_send_messages=True,
        can_send_media_messages=True,
        can_send_polls=True,
        can_send_other_messages=True,
        can_add_web_page_previews=True,
        can_invite_users=True,
        can_change_info=False,
        can_pin_messages=False,
    )
    service_message = await message.reply("Xabar 5 sekunddan so'ng o'chib ketadi.")
    await asyncio.sleep(5)
    await message.chat.restrict(user_id=member_id1, permissions=user_allowed, until_date=0)
    await message.reply(f"Foydalanuvchi @{member.username} yana yozishi mumkin")
    await message.delete()
    await service_message.delete()

# Foydalanuvchini gruxdan quvlash
@dp.message_handler(IsGroup(), Command("ban", prefixes="!/"), AdminFilter())
async def ban_user(message: types.Message):
    try:
        member = message.reply_to_message.from_user
    except:
        my_mess = await message.answer("hatolik aniqlandi qaytadan urunib ko'ring")
        await asyncio.sleep(3)
        await dp.bot.delete_message(message_id=my_mess.message_id, chat_id=my_mess.chat.id)
        return

    member_id1 = member.id
    await message.chat.kick(user_id=member_id1)

    asd = await message.answer(f"Foydalanuvchi {message.reply_to_message.from_user.full_name} guruhdan haydaldi")
    service_message = await message.reply("Xabar 3 sekunddan so'ng o'chib ketadi.")

    await asyncio.sleep(3)
    await message.delete()
    await service_message.delete()
    await asd.delete()
    await message.reply_to_message.delete()


@dp.message_handler(IsGroup(), Command("unban", prefixes="!/"), AdminFilter())
async def unban_user(message: types.Message):
    try:
        member = message.reply_to_message.from_user
    except:
        my_mess = await message.answer("hatolik aniqlandi qaytadan urunib ko'ring")
        await asyncio.sleep(3)
        await dp.bot.delete_message(message_id=my_mess.message_id, chat_id=my_mess.chat.id)
        return
    member_id1 = member.id
    chat_id = message.chat.id
    await message.chat.unban(user_id=member_id1)
    await message.answer(f"Foydalanuvchi {message.reply_to_message.from_user.full_name} grga qo'shilish mumkin")
    service_message = await message.reply("Xabar 5 sekunddan so'ng o'chadi")
    await asyncio.sleep(5)
    await message.delete()
    await service_message.delete()