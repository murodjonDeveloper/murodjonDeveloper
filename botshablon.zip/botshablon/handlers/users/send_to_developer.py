import asyncio

from aiogram import types
from loader import dp
from states.adminSt import My_Admin
from filters import IsPrivate
from aiogram.dispatcher.filters import Command

bad_texts = ('nas', 'krisa', 'tupoy', 'garang', 'axmoq', 'yiban', 'lox',
             'kuppak', 'kuchik', 'dalbayob', 'dalbayop', 'konchenniy', 'pidoras', 'криса', 'далбаеб', 'ебан', 'йибан',
             'kut')


@dp.message_handler(IsPrivate(), Command('Admin'))
async def admin(message: types.Message):
    await message.answer("Adminga qanday taklif yubormoqchisiz")
    await My_Admin.Admin_send.set()


@dp.message_handler(state=My_Admin.Admin_send)
async def to_send(message: types.Message):
    user_text = await message.answer(f"Habar yuborildi✅\n"
                                     f"text: {message.text}\n"
                                     f"foydalanuvchi: {message.from_user.username}")
    await dp.bot.send_message(5291768607, text=f"foydalanuvchi: @{message.from_user.username}\n"
                                               f"text: {message.text}\n"
                                               f"id:{message.from_user.id}")
    await asyncio.sleep(5)
    await user_text.delete()
