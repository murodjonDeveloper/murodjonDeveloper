from aiogram import types
from aiogram.dispatcher.filters.builtin import CommandStart
from loader import dp
from filters import IsPrivate
from utils.set_bot_commands import set_default_commands

@dp.message_handler(CommandStart(), IsPrivate())
async def bot_start(message: types.Message):
    await message.answer(f"Assalomu alaykum, {message.from_user.username}  botga xush kelibsiz!")
    await set_default_commands(dp)


@dp.message_handler(IsPrivate(), commands="help")
async def send_for_menu(message: types.Message):
    await message.answer("❗️❗️❗️bot ishlashi uchun Admin berilishi kerak❗️❗️❗️\n"
                         "❗️❗️❗️botni grupaning Admini ishlata oladi       ❗️❗️❗️\n"
                         "🔵 /mute ['minut'] [komentariya] misol uchun ➡️ [foydalanuvhciga javob yozish] /mute 10 shu tarzda kiritiladi\n"
                         "P.s: bu komandani buzg'unchini yozgan habariga\n"
                         "🔵 /unmute  foydalanuvchini bilmasdan ban qilgan bo'lsangiz uning oldingi yozgan habariga\n"
                         " atvet qilib ishlatishingiz kerak\n"
                         "🔵 /ban guruhdan haydaydi va unga kirishga qo'ymaydi atvet qilinganda ishlaydi\n"
                         "🔵 /unban guruhga qo'shilishga ruxsat beradi atvet bilan ishlaydi\n"
                         "atvet qilib ishlatishingiz kerak\n🔵 to'liq ma'lumot /info_mute ")

@dp.message_handler(IsPrivate(), commands="info_mute")
async def full_info_mute(message: types.Message):
    await message.answer("🔵 /mute komandasida keyin nechi daqiqaga ban qilishni kiritishingiz\n"
                         " mumkin va kamentariya yozishingiz mumkin nima uchun foydalanuvchi yozishdan cheklanganini\n"
                         " agar daqiqani kiritmasangiz uzi avtomatik 5 daqiqani oladi lekin komentariya kirita olmaysiz\n"
                         "🔵 /unmute mudatidan oldin foydalanuvchini guruhga yozish va shu kabi funksiyalarni tiklaydi\n"
                         "🔵 /ban guruhdan haydaydi guruhga o'zi qushilishi uchun /unban komandasi ishlatiladi yoki admin guruhga qo'sha oladi\n"
                         "❗️❗️❗️P.s:Barcha komandalar atvet qilganda ishlaydi va bu komandalarni guruh admini ishlata oladi❗️❗️❗️\n"
                         "dasturchiga taklifingiz bormi unda /Admin")
