from aiogram.dispatcher.filters.state import State, StatesGroup

class My_Admin(StatesGroup):
    Admin_send = State()